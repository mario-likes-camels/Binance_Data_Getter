# Binance_Data_Getter
Used to extract and process data from Binance
