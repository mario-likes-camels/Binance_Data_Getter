from setuptools import setup

setup(name='Binance_Data_Getter',
      version='0.2',
      description='Used to extract and process data from Binance',
      url='https://github.com/mario-likes-camels/Binance_Data_Getter',
      author='Patrick',
      author_email='hi_in@hotmail.com',
      license='MIT',
      packages=['Binance_Data_Getter'],
      zip_safe=False)
      
     
